
package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.CDGalleryDAOException;
import com.keane.training.dao.DetailsDAO;
import com.keane.training.dao.RentalDAO;
import com.keane.training.domain.AlbumDetails;
import com.keane.training.domain.RentalDetails;


public class return1 implements HttpRequestHandler {

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String albumId1=request.getParameter("cd_selected");
		if(albumId1==null)
		{
			
				RequestDispatcher dispatcher1 = request.getRequestDispatcher("Return.jsp");
				request.setAttribute("alb", "No Albums hired");
				dispatcher1.forward(request, response);
				return;
			
		}
		int aid=Integer.parseInt(albumId1);
		System.out.println(aid);
		
		HttpSession session=request.getSession(true);
		String customerId=(String)session.getAttribute("ID");
		int cid=Integer.parseInt(customerId);
		String hid=request.getParameter("hire_ID");
		int hid1=Integer.parseInt(hid);
        System.out.println(cid);
        long millis=System.currentTimeMillis();  
		java.sql.Date hireDate=new java.sql.Date(millis);
		int pay=0;
		

		PrintWriter pw = response.getWriter();
	

try {
	RentalDAO ddao=new RentalDAO();
    RentalDetails rdobj=new RentalDetails(hid1,hireDate);
	//ddao.returnAlbums(rdobj);
    
    List returnAlbum = ddao.returnAlbums(rdobj);
	
	Iterator itr3 = returnAlbum.iterator();
	
	
	while(itr3.hasNext())
	{
		RentalDetails rd3 = new RentalDetails();
		rd3=(RentalDetails)itr3.next();
//		rd3.setCategoryId(rd3.getCategoryId());
//		System.out.println("Album Id: "+ rd3.getAlbumId()+"Hire Price: "+rd3.getHirePrice()+"");
		pay=rd3.getTotalPrice();
		
	}
	
	System.out.println("CD price: "+pay);
	//totalPrice1+=pay;
    Login.t += pay;
	
	request.setAttribute("price", pay);
	request.setAttribute("tprice", Login.t);
	
	RequestDispatcher dispatcher = request.getRequestDispatcher("TotalPrice.jsp");
	dispatcher.forward(request, response);
		pw.println("thank you");
		
			
} catch (Exception e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
	}

}
