package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.DetailsDAO;
import com.keane.training.domain.AlbumDetails;


public class album implements HttpRequestHandler {

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		PrintWriter pw = response.getWriter();
	
		 
		String categoryid =request.getParameter("category_selected");
		pw.println(categoryid);
		System.out.println(categoryid);
	
		List<?> albums = null;
		List album_details = null;
		List list = null;
		DetailsDAO cdgf=new DetailsDAO();
	
		HttpSession session=request.getSession(true);
		RequestDispatcher dispatcher=null;


		try {
			
	
			albums = cdgf.getAlbums( Integer.parseInt(categoryid));
			
			Iterator itr = albums.iterator();
			list = new ArrayList<>();
			while(itr.hasNext()){
				AlbumDetails ald = new AlbumDetails();
				ald = (AlbumDetails)itr.next();
				album_details = new ArrayList();
				album_details.add(ald.getAlbumId());
				album_details.add(ald.getCategoryId());
				album_details.add(ald.getAlbumTitle());
				album_details.add(ald.getHirePrice());
				album_details.add(ald.getNoOfCDs());
				album_details.add(ald.getStatus());
				list.add(album_details);
				System.out.println(album_details);
			
			}
			System.out.println(list);
		session.setAttribute("albums", list);
			dispatcher=request.getRequestDispatcher("AlbumDetails.jsp");
			dispatcher.forward(request, response);
		
		
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
