package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.CustomerDAO;
import com.keane.training.domain.Customer;
//import com.nttdata.cdgallery.service.CDGalleryFacade;

	public class Registration implements HttpRequestHandler {
		static Logger log = Logger.getLogger(Registration.class);

		@Override
		public void handle(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

			PrintWriter out=response.getWriter();
			
			String npassword=request.getParameter("password");
			String fname=request.getParameter("firstName");
			String lname=request.getParameter("secondName");
			String dobstring=request.getParameter("dateOfBirth");
			java.util.Date utilDate = new java.util.Date(dobstring);
			java.sql.Date dob = new java.sql.Date(utilDate.getTime());
			String addr=request.getParameter("address");
			int cno=Integer.parseInt(request.getParameter("contactNo"));
			int ccn=Integer.parseInt(request.getParameter("creditCardNo"));
			String ct=request.getParameter("creditCardType");
			String edatestring=request.getParameter("cardExpiryDate");
			java.util.Date utileDate = new java.util.Date(edatestring);
			java.sql.Date edate = new java.sql.Date(utileDate.getTime());
			
			
			Customer c = new Customer(npassword,fname,lname,dob,addr,cno,ccn,ct,edate);
			
			

			CustomerDAO dao=new CustomerDAO();
	
			try
			{	
				int cid=dao.createCustomer(c);
				if(cid!=0)
				{
			
					RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\success.jsp");
					request.setAttribute("success","User succesfully registered with the system");
					request.setAttribute("ID", cid);
					request.setAttribute("password",npassword);
					dispatcher.forward(request, response);
				}
				else
				{
					System.out.println("invalid");
					
				}
			}
			catch (Exception e) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("Err", e.getMessage());
				dispatcher.forward(request, response);
			}
		}

	}
