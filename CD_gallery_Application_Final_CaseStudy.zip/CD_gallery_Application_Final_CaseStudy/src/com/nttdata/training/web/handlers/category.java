package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.DetailsDAO;
import com.keane.training.domain.MusicalCategory;


public class category implements HttpRequestHandler {

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		PrintWriter pw = response.getWriter();
	
		List<?> category = null;
		List category_details = null;
		List list = null;

		HttpSession session=request.getSession(true);
		RequestDispatcher dispatcher=null;
		DetailsDAO cdgf=new DetailsDAO();
	
		try {

			category = cdgf.getCategories();
			
			Iterator itr = category.iterator();
			list = new ArrayList<>();
			while(itr.hasNext()){
				MusicalCategory mc = new MusicalCategory();
				mc = (MusicalCategory)itr.next();
				category_details = new ArrayList();
				category_details.add(mc.getCategoryId());
				category_details.add(mc.getCategoryName());
				category_details.add(mc.getCategoryDescription());
				list.add(category_details);
			
			}
			System.out.println(list);
		session.setAttribute("category", list);
			dispatcher=request.getRequestDispatcher("Category.jsp");
			dispatcher.forward(request, response);
		
		
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
