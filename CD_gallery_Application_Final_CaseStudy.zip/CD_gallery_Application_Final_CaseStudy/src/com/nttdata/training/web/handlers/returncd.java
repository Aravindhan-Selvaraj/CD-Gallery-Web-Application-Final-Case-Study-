package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.CustomerDAO;
import com.keane.training.dao.DetailsDAO;
import com.keane.training.dao.RentalDAO;
import com.keane.training.domain.AlbumDetails;
import com.keane.training.domain.Customer;
import com.keane.training.domain.MusicalCategory;
import com.keane.training.domain.RentalDetails;
import com.keane.training.domain.User;

public class returncd implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter pw = response.getWriter();
	
		List<?> returncd = null;
		List cd_details = null;
		List list = null;

		HttpSession session=request.getSession(true);
		RequestDispatcher dispatcher=null;
		
	
		try {
			String customerId=(String)session.getAttribute("ID");
			int cid=Integer.parseInt(customerId);
	RentalDAO rdao=new RentalDAO();
	returncd=rdao.getRentalAlbums(cid);
	Iterator itr = returncd.iterator();
	list = new ArrayList<>();
	while(itr.hasNext()){
		RentalDetails rd = new RentalDetails();
	rd= (RentalDetails)itr.next();
	cd_details  = new ArrayList();
	cd_details .add(rd.getHireId());
	cd_details .add(rd.getCustomerId());
	cd_details .add(rd.getAlbumId());
	cd_details .add(rd.getTotalPrice());
	

		list.add(cd_details );
	
	}
	System.out.println(list);
	session.setAttribute("CD", list);
	
	
	
	dispatcher=request.getRequestDispatcher("Return.jsp");
	dispatcher.forward(request, response);
	

	
	
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

}

}
	