package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.RentalDAO;
import com.keane.training.domain.AlbumDetails;
import com.keane.training.domain.RentalDetails;

public class hire implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(hire.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		long millis=System.currentTimeMillis();  
		java.sql.Date hireDate=new java.sql.Date(millis);
        try
		{
        	String albumId1=request.getParameter("album_selected1");
		int aid=Integer.parseInt(albumId1);
    	RentalDetails rd=new RentalDetails();
    	RentalDAO rdao=new RentalDAO();
	    int hireid=rd.getHireId();
	    HttpSession session=request.getSession(true);
	    String customerId=(String)session.getAttribute("ID");
		int cid=Integer.parseInt(customerId);
        System.out.println(cid);
        String date=("18-02-2019");
        RentalDAO ddao=new RentalDAO();
    RentalDetails rdobj=new RentalDetails(cid,aid,hireDate);
    
	AlbumDetails rentalObj2=new AlbumDetails(aid);
   int hid= ddao.rentalDetails(rdobj);

        	  if(hid!=0)
  			{
        	   	request.setAttribute("HID", hid);
       RequestDispatcher dispatcher = request.getRequestDispatcher("RentalId.jsp");
			dispatcher.forward(request, response);
	}
		}
        catch(Exception e)
		{
			System.out.println(e);
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("error.jsp");
			request.setAttribute("Err", e.getMessage());
			dispatcher.forward(request, response);

		}}
	

}
