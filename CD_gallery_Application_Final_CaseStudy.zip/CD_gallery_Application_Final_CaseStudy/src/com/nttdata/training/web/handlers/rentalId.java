package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.DetailsDAO;
import com.keane.training.dao.RentalDAO;
import com.keane.training.domain.AlbumDetails;
import com.keane.training.domain.RentalDetails;

public class rentalId implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String albumId=request.getParameter("album_selected");
		if(albumId.isEmpty())
		{
		
					request.setAttribute("sel", "No album selected ");
					RequestDispatcher dispatcher = request.getRequestDispatcher("AlbumDetails.jsp");
					dispatcher.forward(request, response);
					return;
	          /* */

			
		}
		int aid=Integer.parseInt(albumId);
		int flag = -1;
		DetailsDAO dd=new DetailsDAO();
/**/
		try {
		boolean k=dd.checkAlbum(aid);
		    if(k==true)
			{
			
				System.out.println("album is available");
				request.setAttribute("avail", "Album is available");
				RequestDispatcher dispatcher = request.getRequestDispatcher("available.jsp");
				dispatcher.forward(request, response);
          /* */
        
                
			}
			
			else
			{
				out.println("album not available");
				RequestDispatcher dispatcher = request.getRequestDispatcher("album_not_available.jsp");
				request.setAttribute("Err","invalid album");
				dispatcher.forward(request, response);
			}
		
		} 
		catch(Exception e)
		{
			System.out.println(e);
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("error.jsp");
			request.setAttribute("Err", e.getMessage());
			dispatcher.forward(request, response);

		}}
	

}
	