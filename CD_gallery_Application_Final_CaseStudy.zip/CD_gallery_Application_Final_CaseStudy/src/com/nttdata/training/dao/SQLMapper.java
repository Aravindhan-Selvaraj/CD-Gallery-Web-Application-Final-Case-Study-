package com.keane.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.keane.dbfw.ResultMapper;
import com.keane.training.domain.AlbumDetails;
import com.keane.training.domain.Customer;
import com.keane.training.domain.MusicalCategory;
import com.keane.training.domain.RentalDetails;
import com.keane.training.domain.User;

public class SQLMapper {
	public static final String FETCHCUSTOMER=
		"select * from CUSTOMER";
	public static final String FETCHIDPASS=
		"select CustomerId,Password from Customer ";	
	public static final String INSERTCUSTOMER=
			"insert into Customer values(custIDseq.nextval,?,?,?,?,?,?,?,?,?)";
	public static final String FETCHID=
			"select max(CustomerId) from CUSTOMER";
	public static final String INSERTUSER=
			"insert into User1 values(userIdseq.nextval,?)";
	public static final String FETCHCUSTOMERID=
			"select custID.currval from CUSTOMER";
	
	public static final String FETCHMUSICALCATEGORY=
			"select * from MUSICALCATEGORY";
	
	public static final String FETCHALBUMCATEGORY=
			"select * from AlbumDetails where CategoryId=?";
	
	public static final String ALBUMCHECK=
			"select Status from AlbumDetails where AlbumId=?";
	public static final String UPDATEALBUMSTATUS=
			"update AlbumDetails set status='B' where AlbumId=? and NumberOfCDs=0";
	public static final String UPDATERENTALDETAILS=
			"insert into RentalDetails values(hireIdseq.nextval,?,?,?,'','C',?)";
	public static final String READHIREPRICE=
			"select HirePrice from AlbumDetails where AlbumId=?";
	public static final String READHIREID=
			"select max(HireId) from RentalDetails";
	public static final String GETRENTALALBUMS=
			"select * from RentalDetails where CustomerId=? and Status='C'";
	public static final String UPDATERENTALALBUMDETAILS=
			"update AlbumDetails set status='A' where AlbumId=? and Status='B' and NumberOfCDs>0";
	public static final String UPDATERENTALTABLE=
			"update RentalDetails set status='R',ReturnDate=(select sysdate from dual) where HireId=? and Status='C'";
	public static final String READPRICE=
			"select HireId,TotalHirePrice from RentalDetails where AlbumId=? and Status='C' ";
			//"in (select AlbumId from RentalDetails where CustomerId=? and Status=?)";
	
	public static final String GETCDCOUNT=
			"select * from AlbumDetails where AlbumId=?";
	
	public static final String COUNTUPDATE=
			"update AlbumDetails set NumberOfCDs=? where AlbumId=?";
	public static final String FINDALBUMID=
			"select AlbumId from RentalDetails where HireId=?";

	
	
	public static final ResultMapper USERMAPPER=
			new ResultMapper()
		{
			public Object mapRow(ResultSet rs) throws SQLException {
			int id=	rs.getInt(1);
			String name=rs.getString(2);
			User c=new User(id,name);
				return c;
			}//mapRow
			
		};//Anonymous class
	public static final ResultMapper MUSICALCATEGORYMAPPER=
		new ResultMapper()
	{
		public Object mapRow(ResultSet rs) throws SQLException {
		int cateId = rs.getInt(1);
		String cateName = rs.getString(2);
		String cateDesc = rs.getString(3);
		MusicalCategory mc = new MusicalCategory();
		mc.setCategoryId(cateId);
		mc.setCategoryName(cateName);
		mc.setCategoryDescription(cateDesc);
		return mc;
		}//mapRow
	};
		public static final ResultMapper ALBUMCATEGORYMAPPER=
				new ResultMapper()
			{
				public Object mapRow(ResultSet rs) throws SQLException {
				int albumId = rs.getInt(1);
				int acateId = rs.getInt(2);
				String albumTitle = rs.getString(3);
				int hirePrice = rs.getInt(4);
				int noOfCDs = rs.getInt(5);
				String status = rs.getString(6);
				AlbumDetails ac = new AlbumDetails(albumId,acateId,albumTitle,hirePrice,noOfCDs,status);
				ac.setAlbumId(albumId);
				ac.setCategoryId(acateId);
				ac.setAlbumTitle(albumTitle);
				ac.setHirePrice(hirePrice);
				ac.setNoOfCDs(noOfCDs);
				ac.setStatus(status);
				
				return ac;
				
				}//mapRow
				
		};//Anonymous class	
	
				public static final ResultMapper ALBUMCHECKMAPPER=
						new ResultMapper()
					{
						public Object mapRow(ResultSet rs) throws SQLException {
						String status =rs.getString(1);
						
						return status;
				}//mapRow
				
			};//Anonymous class	
			
			public static final ResultMapper READHIREPRICEMAPPER=
					new ResultMapper() {
						
						@Override
						public Object mapRow(ResultSet rs) throws SQLException {
							int pri = rs.getInt(1);
							return pri;
						}
					};
			public static final ResultMapper READHIREIDMAPPER=
					new ResultMapper() {
								
						@Override
						public Object mapRow(ResultSet rs) throws SQLException {
							int hireId = rs.getInt(1);
							return hireId;
						}
					};
			public static final ResultMapper GETRENTALDETAILSMAPPER=
					new ResultMapper() {
										
						@Override
						public Object mapRow(ResultSet rs) throws SQLException {
							int hireId=rs.getInt(1);
							int customerId = rs.getInt(2);
							int albumId=rs.getInt(3);
							int hirePrice = rs.getInt(7);
							
							RentalDetails ad= new RentalDetails(hireId,customerId,albumId,hirePrice);
							
							//AlbumDetails ad = new AlbumDetails(albumId,categoryId,albumTitle,hirePrice,noOfCds,status);
							//ad.setCategoryId(categoryId);
							
						return ad;
						   }
					};		
					
			public static final ResultMapper UPDATERENTALTABLEPMAPPER=
					new ResultMapper() {
										
						@Override
						public Object mapRow(ResultSet rs) throws SQLException {
							int cdprice=rs.getInt(2);
							int hid=rs.getInt(1);
							RentalDetails price=new RentalDetails(hid,cdprice);
							return price;
		
						   }
					};
					
					
					
					
			public static final ResultMapper GETCDCOUNTMAPPER=
							new ResultMapper() {
												
								@Override
								public Object mapRow(ResultSet rs) throws SQLException {
									int cds=rs.getInt(5);
									
									
									AlbumDetails cd = new AlbumDetails(cds);
				
								return cd;
								   }
							};
							
			public static final ResultMapper FINDALBUMIDMAPPER=new ResultMapper()
							{
								public Object mapRow(ResultSet rs)throws SQLException
								{
									int alb=rs.getInt(1);
									RentalDetails fr=new RentalDetails(alb);
									
									return fr;
									
								}
								
							};				
			
			
			
			
			
}

//	public static final ResultMapper CUSTOMERMAPPER=
//			new ResultMapper()
//		{
//			public Object mapRow(ResultSet rs) throws SQLException {
//			String password =	rs.getString(2);
//			String firstName=rs.getString(3);
//			String secondName=rs.getString(4);
//			Date dateOfBirth=rs.getDate(5);
//			String address=rs.getString(6);
//			int contactNo=rs.getInt(7);
//			int creditCardNo=rs.getInt(8);
//			String creditCardType=rs.getString(9);
//			Date cardExpiryDate=rs.getDate(10);
//			Customer c=new Customer(password,firstName,secondName,dateOfBirth,address,contactNo,creditCardNo,creditCardType,cardExpiryDate);
//				return c;
//			}//mapRow
//			
//		};//Anonymous class
//}









