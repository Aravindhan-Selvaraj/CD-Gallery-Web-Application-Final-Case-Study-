package com.keane.training.dao;

public class CDGalleryDAOException extends Exception {

	public CDGalleryDAOException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CDGalleryDAOException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
