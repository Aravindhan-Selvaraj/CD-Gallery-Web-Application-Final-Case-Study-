package com.keane.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

//drop table Customer;
//drop sequence custIdseq;
//drop table User1;
//drop sequence userIdseq;
//drop table MusicalCategory;
//drop table AlbumDetails;
//drop table RentalDetails;
//drop sequence hireIdSeq;

public class tableCreation {
	public static void main(String[] args)
	{
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","TRDBFCS","TRDBFCS");
		Statement stmt=con.createStatement();			
		int x=stmt.executeUpdate("create table Customer(CustomerId number(5) ,Password varchar2(20) ,First_Name varchar2(30) ,Second_Name varchar2(30) ,DateOfBirth Date ,Address varchar2(60) ,Contact number(9) , CreditCardNumber number(16), CreditCardType varchar2(10), CardExpiryDate Date, primary key (CustomerID) )");
		System.out.println(x);
		int x1=stmt.executeUpdate("CREATE SEQUENCE custIdseq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 1000 cache 20");
		System.out.println(x1);
		int x2=stmt.executeUpdate("create table User1(UserId number(5), Password varchar2(25), foreign key(UserId) references Customer(CustomerId))");
		System.out.println(x2);
		int x3=stmt.executeUpdate("CREATE SEQUENCE userIdseq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 1000 cache 20");
		System.out.println(x3);
		int x4=stmt.executeUpdate("create table MusicalCategory(CategoryId number(10), CategoryName varchar2(45) NOT NULL ,CategoryDescription varchar2(45), primary key(CategoryId), UNIQUE(CategoryName)  )");
		System.out.println(x4);
		int x5=stmt.executeUpdate("begin insert into MusicalCategory values(1,'English','Englis songs');insert into MusicalCategory values(2,'Hindi','Hindi songs');insert into MusicalCategory values(3,'Kannada','Kannada Songs');insert into MusicalCategory values(4,'Rap','Rap songs');insert into MusicalCategory values(5,'Love','Romantic songs');end;");
		System.out.println(x5);
		int x6=stmt.executeUpdate("create table AlbumDetails(AlbumId number(10), CategoryId number(10), AlbumTitle varchar2(30) NOT NULL, HirePrice number(5,2), NumberOfCDs number(2) NOT NULL, Status varchar2(4) NOT NULL, primary key(AlbumId), foreign key(CategoryId) references MusicalCategory(CategoryId))");
		System.out.println(x6);
		int x7=stmt.executeUpdate("begin insert into AlbumDetails values(1,1,'Alan Walker',30,3,'A');insert into AlbumDetails values(2,1,'Ariana Grande',20,3,'A');insert into AlbumDetails values(3,1,'Marshmello',10,3,'A');insert into AlbumDetails values(4,2,'Kabir Singh',30,3,'A');insert into AlbumDetails values(5,2,'Badla',20,3,'A');insert into AlbumDetails values(6,2,'PK',10,3,'A');insert into AlbumDetails values(7,3,'Kirik Party',30,3,'A');insert into AlbumDetails values(8,3,'Googly',20,3,'A');insert into AlbumDetails values(9,3,'Lucia',10,3,'A');insert into AlbumDetails values(10,4,'Gully Boy',30,3,'A');insert into AlbumDetails values(11,4,'Rock ON',20,3,'A');insert into AlbumDetails values(12,4,'Befikre',10,3,'A');insert into AlbumDetails values(13,5,'Aashiqui 2',30,3,'A');insert into AlbumDetails values(14,5,'Murder 2',20,3,'A');insert into AlbumDetails values(15,5,'CityLights',10,3,'A');end;");
		System.out.println(x7);
		int x8=stmt.executeUpdate("create table RentalDetails(HireId number(6), CustomerId number(5), AlbumId number(10),HireDate Date, ReturnDate Date, Status varchar2(4) NOT NULL, TotalHirePrice number(5,2), primary key(HireId), foreign key(CustomerId) references Customer(CustomerId), foreign key(AlbumId) references AlbumDetails(AlbumId) )");
		System.out.println(x8);
		int x9=stmt.executeUpdate("CREATE SEQUENCE hireIdseq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 1000 cache 20");
		System.out.println(x9);
		

	}
	
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
}


