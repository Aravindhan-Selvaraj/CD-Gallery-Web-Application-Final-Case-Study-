package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.AlbumDetails;
import com.keane.training.domain.RentalDetails;

public class RentalDAO {

		public int rentalDetails(final RentalDetails rd) throws DBFWException, CDGalleryDAOException, DBConnectionException
		{
			int hireId=0;
			int fcount=0;
			final int ucount;
			final int hirePrice;
			List readhirePrice=null;
			List hireIdRentalDetails=null;
			List cdcount=null;
			ConnectionHolder ch=null;
			Connection con=null;
			final int customerId = rd.getCustomerId();
			final int albumId = rd.getAlbumId();
			final java.sql.Date hireDate = rd.getHireDate();
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				
				final ParamMapper CDScountPmapper = new ParamMapper() {
					
				@Override
				public void mapParam(PreparedStatement preStmt) throws SQLException {
					// TODO Auto-generated method stub
						preStmt.setInt(1,albumId);
					}
				}; 
				
				cdcount = DBHelper.executeSelect(con, SQLMapper.GETCDCOUNT, SQLMapper.GETCDCOUNTMAPPER, CDScountPmapper);
				
				Iterator itr1 = cdcount.iterator();
				while( itr1.hasNext())
				{
					AlbumDetails ad = (AlbumDetails)itr1.next();
					fcount=ad.getNoOfCDs();
					
				}
				ucount=fcount-1;
				
				final ParamMapper UPDATECDSCOUNTP = new ParamMapper() {
					
					@Override
					public void mapParam(PreparedStatement preStmt) throws SQLException {
						// TODO Auto-generated method stub
						preStmt.setInt(1, ucount);
						preStmt.setInt(2, albumId);
					}
				};
				DBHelper.executeUpdate(con, SQLMapper.COUNTUPDATE, UPDATECDSCOUNTP);
				
				
				final ParamMapper UPDATEALBUMSTATUSP = new ParamMapper() {
					
					@Override
					public void mapParam(PreparedStatement preStmt) throws SQLException {
						// TODO Auto-generated method stub
						preStmt.setInt(1, rd.getAlbumId());
					}
				};
				DBHelper.executeUpdate(con, SQLMapper.UPDATEALBUMSTATUS, UPDATEALBUMSTATUSP);
				
				final ParamMapper READHIREPRICEPMAPPER = new ParamMapper() {
					
					@Override
					public void mapParam(PreparedStatement preStmt) throws SQLException {
						// TODO Auto-generated method stub
						preStmt.setInt(1, rd.getAlbumId());
					}
				};
				readhirePrice=DBHelper.executeSelect(con, SQLMapper.READHIREPRICE,SQLMapper.READHIREPRICEMAPPER, READHIREPRICEPMAPPER);
				hirePrice=(Integer)readhirePrice.get(0);
	
	
				
				final ParamMapper UPDATERENTALDETAILSPMAPPER = new ParamMapper() {
					
					@Override
					public void mapParam(PreparedStatement preStmt) throws SQLException {
						// TODO Auto-generated method stub
						preStmt.setInt(1, customerId);
						preStmt.setInt(2, albumId);
						preStmt.setDate(3, hireDate);
						preStmt.setInt(4, hirePrice);
						
					}
				};
				DBHelper.executeUpdate(con, SQLMapper.UPDATERENTALDETAILS, UPDATERENTALDETAILSPMAPPER);
				
				hireIdRentalDetails=DBHelper.executeSelect(con,SQLMapper.READHIREID,SQLMapper.READHIREIDMAPPER);
						
				
				
				
						
			} catch (DBConnectionException e) {
				throw new DBConnectionException("Unable to connect to db"+e);
			
			}
			finally {

				try {

					if (con != null)
						con.close();

				} catch (SQLException e) {
				}
			}
			Iterator itr = hireIdRentalDetails.iterator();
			hireId =(Integer) itr.next();
			
			return hireId;
		
	}

		public List getRentalAlbums(int id) throws DBConnectionException {
			// TODO Auto-generated method stub
			ConnectionHolder ch =null;
			Connection con = null;
			
			List rentalAlbumDetails=null;
			final int cid =id;
			try
			{
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				
				final ParamMapper GETRENTALALBUMDETAILSPMAPPER = new ParamMapper() {
					
					@Override
					public void mapParam(PreparedStatement preStmt) throws SQLException {
						// TODO Auto-generated method stub
						preStmt.setInt(1,cid);
					}
				}; 
				
				rentalAlbumDetails = DBHelper.executeSelect(con, SQLMapper.GETRENTALALBUMS, SQLMapper.GETRENTALDETAILSMAPPER, GETRENTALALBUMDETAILSPMAPPER);
				
			}
			catch (DBConnectionException e) {
				throw new DBConnectionException("Unable to connect to db"+e);
			
			}
			finally {

				try {

					if (con != null)
						con.close();

				} catch (SQLException e) {
				}
			}
			
			
			
			
			
			
			return rentalAlbumDetails;
		}

		public List returnAlbums(final RentalDetails rd1) throws DBFWException, DBConnectionException {
			// TODO Auto-generated method stub
						ConnectionHolder ch =null;
						Connection con = null;
						List returnAlbumDetails=null;
						List gcdcount=null;
						final int gucount;
						int gfcount=0;
						int albuid=0;
						final int albuuid;
					
						
						long millis=System.currentTimeMillis();  
						final java.sql.Date returnDate=new java.sql.Date(millis);
						
						try
						{
							ch=ConnectionHolder.getInstance();
							con=ch.getConnection();
							
							final ParamMapper FINDALBUMPMapper= new ParamMapper() {
								
								@Override
								public void mapParam(PreparedStatement preStmt) throws SQLException {
									// TODO Auto-generated method stub
									preStmt.setInt(1, rd1.getHireId());
								}
							};
							List albid=DBHelper.executeSelect(con, SQLMapper.FINDALBUMID,SQLMapper.FINDALBUMIDMAPPER, FINDALBUMPMapper);
							
							
				            Iterator itr5=albid.iterator();
							
							while(itr5.hasNext())
							{
							
								RentalDetails facd=(RentalDetails)itr5.next();
								 albuid=facd.getAlbumId();
							}
							
							
							 albuuid=albuid;
							
							
							final ParamMapper gCDScountPmapper = new ParamMapper() {	
								@Override
								public void mapParam(PreparedStatement preStmt) throws SQLException {
									// TODO Auto-generated method stub
										preStmt.setInt(1,albuuid);
									}
								}; 
								
								gcdcount = DBHelper.executeSelect(con, SQLMapper.GETCDCOUNT, SQLMapper.GETCDCOUNTMAPPER, gCDScountPmapper);
								
								Iterator itr1 = gcdcount.iterator();
								while( itr1.hasNext())
								{
									AlbumDetails gad = (AlbumDetails)itr1.next();
									gfcount=gad.getNoOfCDs();
									
								}
								gucount=gfcount+1;
								
								final ParamMapper gUPDATECDSCOUNTP = new ParamMapper() {
									
									@Override
									public void mapParam(PreparedStatement preStmt) throws SQLException {
										// TODO Auto-generated method stub
										preStmt.setInt(1, gucount);
										preStmt.setInt(2, albuuid);
									}
								};
								DBHelper.executeUpdate(con, SQLMapper.COUNTUPDATE, gUPDATECDSCOUNTP);
							
							
							
							final ParamMapper UPDATERENTALALBUMDETAILSPMAPPER = new ParamMapper() {
								
								@Override
								public void mapParam(PreparedStatement preStmt) throws SQLException {
									// TODO Auto-generated method stub
									preStmt.setInt(1,albuuid);
								}
							}; 
							
							DBHelper.executeUpdate(con, SQLMapper.UPDATERENTALALBUMDETAILS,UPDATERENTALALBUMDETAILSPMAPPER);
							
							final ParamMapper GETPRICEPMAPPER = new ParamMapper() {
								
								@Override
								public void mapParam(PreparedStatement preStmt) throws SQLException {
									// TODO Auto-generated method stub
									preStmt.setInt(1,albuuid);
									//preStmt.setString(2, "C");
									

								}
							}; 
							
							returnAlbumDetails=DBHelper.executeSelect(con, SQLMapper.READPRICE,SQLMapper.UPDATERENTALTABLEPMAPPER,GETPRICEPMAPPER);
							
							final ParamMapper UPDATERENTALTABLEPMAPPER = new ParamMapper() {
								
								@Override
								public void mapParam(PreparedStatement preStmt) throws SQLException {
									// TODO Auto-generated method stub
								
									preStmt.setInt(1,rd1.getHireId());
									

								}
							}; 
					
							DBHelper.executeUpdate(con, SQLMapper.UPDATERENTALTABLE,UPDATERENTALTABLEPMAPPER);
							
	
							
						}
						catch (DBConnectionException e) {
							throw new DBConnectionException("Unable to connect to db"+e);
						
						}
						finally {

							try {

								if (con != null)
									con.close();

							} catch (SQLException e) {
							}
						}

						
						return returnAlbumDetails;
		}
		
		

}
