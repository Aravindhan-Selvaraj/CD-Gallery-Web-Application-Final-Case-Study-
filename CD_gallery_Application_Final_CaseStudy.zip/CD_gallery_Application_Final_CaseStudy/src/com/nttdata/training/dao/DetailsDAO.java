package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.RentalDetails;

public class DetailsDAO {
static Logger log=Logger.getLogger(DetailsDAO.class);
	
	public static List getCategories() throws DBFWException, CDGalleryDAOException, DBConnectionException
	{
		List mcategories=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			mcategories=DBHelper.executeSelect(con,SQLMapper.FETCHMUSICALCATEGORY,SQLMapper.MUSICALCATEGORYMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return mcategories;
		
	}//get Music Categories

	public List getAlbums(int musicCateId)throws DBFWException, CDGalleryDAOException, DBConnectionException
	{
		List acategories=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			final int acateId=musicCateId;

			
			final ParamMapper ALBUMCATEGORYPMAPPER = new ParamMapper() {
				
				
				public void mapParam(PreparedStatement preStmt) throws SQLException {
					// TODO Auto-generated method stub
					preStmt.setInt(1,acateId);
				}
			};
			
			acategories=DBHelper.executeSelect(con,SQLMapper.FETCHALBUMCATEGORY,SQLMapper.ALBUMCATEGORYMAPPER,ALBUMCATEGORYPMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return acategories;
		
	}//get Album Categories

	public boolean checkAlbum(int albumId) throws DBConnectionException {
		// TODO Auto-generated method stub
		List sta=null;
		ConnectionHolder ch=null;
		Connection con=null;
		boolean check = false;
		final int albmId = albumId;
		String expectedStatus = "A";
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			
			final ParamMapper ALBUMCHECKPMAPPER = new ParamMapper() {
				
				
				public void mapParam(PreparedStatement preStmt) throws SQLException {
					// TODO Auto-generated method stub
					preStmt.setInt(1,albmId);
				}
			};
			
			sta=DBHelper.executeSelect(con,SQLMapper.ALBUMCHECK,SQLMapper.ALBUMCHECKMAPPER,ALBUMCHECKPMAPPER);
			
			String status = (String) sta.get(0);
			if(status.equalsIgnoreCase(expectedStatus))
			{
				check =true;
			}
			
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		return 	check;
	}

}
	
	
	
