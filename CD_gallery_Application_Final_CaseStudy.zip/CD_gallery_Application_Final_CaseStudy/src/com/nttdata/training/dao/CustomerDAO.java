package com.keane.training.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.dao.CDGalleryDAOException;
import com.keane.training.domain.User;
import com.keane.training.domain.Customer;


public class CustomerDAO {
	
	static Logger log=Logger.getLogger(CustomerDAO.class);
	
	public boolean validateRegisteredCustomer(User user) throws DBFWException, CDGalleryDAOException, DBConnectionException, SQLException
	{
		
		ConnectionHolder ch=null;
		Connection con=null;
		boolean tf = false;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				Statement stmt=con.createStatement();
				ResultSet rs=stmt.executeQuery(SQLMapper.FETCHIDPASS);
				
				while(rs.next())
				{
					if(rs.getInt(1)==user.getCustomerId() )
					{	
						if(rs.getString(2).equalsIgnoreCase(user.getPassword()))
						{
							tf=true;
						}
						else
						{
						System.out.println("Wrong Password ");	
						}
					}
//					else
//					{
//						System.out.println("Wrong Username");
//					}
					
					
				}	
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return tf;
		
	}//validate and returns true if id/pass match Customerid/password  or else false 

	public int createCustomer(final Customer c) throws SQLException 
	{
	
		ConnectionHolder ch=null;
		Connection con=null;
		
		int cid = 0;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTPCUSTOMER=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					preStmt.setString(1, c.getPassword());
					preStmt.setString(2, c.getFirstName());
					preStmt.setString(3, c.getSecondName());
					preStmt.setDate(4,  (java.sql.Date)c.getDateOfBirth());
					preStmt.setString(5, c.getAddress());
					preStmt.setInt(6, c.getContactNo());
					preStmt.setInt(7, c.getCreditCardNo());
					preStmt.setString(8, c.getCreditCardType());
					preStmt.setDate(9, (java.sql.Date)c.getCardExpiryDate());
				}
				
			};//
			
		DBHelper.executeUpdate(con,SQLMapper.INSERTCUSTOMER,INSERTPCUSTOMER);
		
		final ParamMapper INSERTPUSER=new ParamMapper()
		{

			
			public void mapParam(PreparedStatement preStmt)
					throws SQLException {

				preStmt.setString(1, c.getPassword());
				
			}
			
		};// inser user
		
	DBHelper.executeUpdate(con,SQLMapper.INSERTUSER,INSERTPUSER);
		
		Statement stmt =con.createStatement();
		ResultSet rs = stmt.executeQuery(SQLMapper.FETCHID);
		while(rs.next())
		{
			cid =rs.getInt(1);
		}
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		return cid;
		
		
	}//insert customer
	

		
}
