package com.keane.training.domain;

public class AlbumDetails {

	private int albumId;
	private int categoryId;
	private String albumTitle;
	private int hirePrice;
	private int noOfCDs;
	private String status;
	
	public AlbumDetails()
	{
		
	}
	
	public AlbumDetails(int albumId,int categoryId, String albumTitle,int price,int noOfCDs,String status)
	{
		this.albumId=albumId;
		this.categoryId = categoryId;
		this.albumTitle=albumTitle;
		hirePrice=price;
		this.noOfCDs=noOfCDs;
		this.status=status;
	}
	
	public AlbumDetails(int albumId,int price)
	{
		this.albumId=albumId;
		hirePrice=price;
		
	}

	public AlbumDetails(int cds) {
		// TODO Auto-generated constructor stub
		noOfCDs=cds;
	}

	public int getAlbumId() {
		return albumId;
	}

	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	public int getHirePrice() {
		return hirePrice;
	}

	public void setHirePrice(int hirePrice) {
		this.hirePrice = hirePrice;
	}

	public int getNoOfCDs() {
		return noOfCDs;
	}

	public void setNoOfCDs(int noOfCDs) {
		this.noOfCDs = noOfCDs;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}
