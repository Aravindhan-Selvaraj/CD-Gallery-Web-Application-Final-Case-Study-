package com.keane.training.domain;

import java.util.Date;

public class Customer {

	private int customerId;
	private String password;
	private String firstName;
	private String secondName;
	private Date dateOfBirth;
	private String address;
	private int contactNo;
	private int creditCardNo;
	private String creditCardType;
	private Date cardExpiryDate;
	private User user;
	
	public Customer()
	{
		
	}
	public Customer(String password, String firstName, String lastName, java.sql.Date dateOfBirth,
			 String address, int contactNumber, int creditCardNumber, String creditCardType,
			 java.sql.Date cardExpiryDate)
	{
		this.password=password;
		this.firstName=firstName;
		secondName=lastName;
		this.dateOfBirth=dateOfBirth;
		this.address=address;
		contactNo=contactNumber;
		creditCardNo=creditCardNumber;
		this.creditCardType=creditCardType;
		this.cardExpiryDate=cardExpiryDate;
	}
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public int getCreditCardNo() {
		return creditCardNo;
	}
	public void setCreditCardNo(int creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	public String getCreditCardType() {
		return creditCardType;
	}
	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}
	public Date getCardExpiryDate() {
		return cardExpiryDate;
	}
	public void setCardExpiryDate(Date cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
}
