package com.keane.training.domain;

import java.sql.Date;
import java.util.List;

public class RentalDetails {

	private int hireId;
	private int customerId;
	private int albumId;
	private Date hireDate;
	private Date returnDate;
	private String status;
	private int totalPrice;
	private List rentalList;
	public RentalDetails()
	{
		
	}
	public RentalDetails(int hireId,int custId,int albumId,Date carryDate)
	{
		this.hireId=hireId;
		customerId=custId;
		this.albumId=albumId;
		hireDate=carryDate;
		
	}
	
	
	public RentalDetails(int hireId, int price)
	{
		this.hireId=hireId;
		totalPrice=price;
	}
	public RentalDetails(int custId,int albumId,Date carryDate)
	{
		
		customerId=custId;
		this.albumId=albumId;
		hireDate=carryDate;
		
	}
	
	public RentalDetails(int hiid, int custid,int alid, int hireprice) {
		// TODO Auto-generated constructor stub
	
		hireId=hiid;
		customerId=custid;
		albumId=alid;
		totalPrice=hireprice;
	}
	public RentalDetails(int alb) {
		// TODO Auto-generated constructor stub
	
		albumId=alb;
	}
	public RentalDetails(int hireId,Date carryDate)
	{
		
		this.hireId=hireId;
		hireDate=carryDate;
		
	}
	
	
	public int getHireId() {
		return hireId;
	}
	public void setHireId(int hireId) {
		this.hireId = hireId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getAlbumId() {
		return albumId;
	}
	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public List getRentalList() {
		return rentalList;
	}
	public void setRentalList(List rentalList) {
		this.rentalList = rentalList;
	}
	
	
	
	
}
